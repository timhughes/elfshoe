"""Core package for iPXE menu generation.

This package contains the core functionality for generating
iPXE menus, including data models, URL validation, and
menu generation.
"""

from .models import BootEntry, DistributionMenu
from .validator import URLValidator
from .generator import MenuGenerator

__all__ = [
    'BootEntry',
    'DistributionMenu',
    'URLValidator',
    'MenuGenerator',
]
