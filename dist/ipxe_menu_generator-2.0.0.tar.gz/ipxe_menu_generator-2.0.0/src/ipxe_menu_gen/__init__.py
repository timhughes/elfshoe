"""iPXE Menu Generator package."""

from .core import BootEntry, DistributionMenu, URLValidator, MenuGenerator
from .distributions import get_metadata_fetcher, AbstractMetadataFetcher

__version__ = "2.0.0"
__all__ = [
    "BootEntry",
    "DistributionMenu",
    "URLValidator",
    "MenuGenerator",
    "get_metadata_fetcher",
    "AbstractMetadataFetcher",
]
