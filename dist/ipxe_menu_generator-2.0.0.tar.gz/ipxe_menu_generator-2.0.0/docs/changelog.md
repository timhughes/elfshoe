# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [2.0.0] - 2026-02-07

### Added

- **Modular Architecture**: Refactored into proper Python package structure
  - `src/ipxe_menu_gen/` package with submodules
  - `core/` subpackage for reusable components
  - `distributions/` subpackage for OS-specific plugins
- **Plugin System**: AbstractMetadataFetcher base class and provider registry
- **Hatch Build System**: Modern packaging with hatchling
- **Hatch Environments**: Isolated dev, test, and lint environments
- **Module Entry Point**: Can run as `python -m ipxe_menu_gen`
- **Command Entry Point**: `ipxe-menu-gen` command when installed
- **Pytest Configuration**: `pythonpath` in pyproject.toml for clean imports
- **Builder Module**: Separated DistributionBuilder into own file
- **CLI Module**: Separated command-line interface logic
- **Error Timeout Configuration**: `error_timeout` in menu config
- **Comprehensive Documentation**:
  - ARCHITECTURE.md - System design
  - ADDING_DISTRIBUTIONS.md - Extension guide
  - Updated all existing documentation

### Changed

- **Package Structure**: Moved from flat `src/` to proper package
  - `src/ipxe_menu_gen.py` → Split into multiple modules
  - `src/core/` → `src/ipxe_menu_gen/core/`
  - `src/distributions/` → `src/ipxe_menu_gen/distributions/`
- **Dynamic Distributions**: Now require `metadata_provider` field in config
- **Test Imports**: Removed `sys.path` manipulation, use clean imports
- **Makefile**: Removed PYTHONPATH from test commands (uses pytest config)
- **Build System**: setuptools → hatchling
- **pyproject.toml**: Updated for Hatch, added `[tool.ruff.lint]`
- **Entry Points**: Updated from `ipxe_menu_gen:main` to `ipxe_menu_gen.cli:main`

### Fixed

- **Line Length**: Fixed E501 error in builder.py
- **Code Formatting**: All code formatted with Black
- **Ruff Warnings**: Moved deprecated config to `[tool.ruff.lint]`
- **Import Paths**: Proper package imports throughout

### Removed

- sys.path manipulation in test files
- PYTHONPATH requirements from Makefile test commands
- Old setuptools configuration

## [1.0.0] - 2026-02-06

### Added

- Initial release with configuration-driven menu generation
- Jinja2 templating system
- URL validation
- Dynamic version detection for Fedora
- Static version lists for CentOS and Debian
- Error handling with pause before menu return
- Configurable menu timeout
- Template-based menu generation
- Comprehensive test suite (11 tests)
- Documentation (README, TESTING, QUICKREF, OVERVIEW)
- Makefile for common tasks
- Example configuration file

### Features

- Configuration via YAML
- Multiple distribution support
- Custom boot parameters
- Additional menu items (shell, exit, chain)
- Fast mode (skip URL validation)
- Verbose and quiet modes

## [Unreleased]

### Planned

- More metadata providers (CentOS, Debian, Ubuntu)
- Increased test coverage (>80%)
- CI/CD integration examples
- Multi-architecture support (ARM)
- Metadata caching
- Configuration validation with JSON Schema
- PyPI publication

---

[2.0.0]: https://github.com/yourusername/ipxe-menu-generator/compare/v1.0.0...v2.0.0
[1.0.0]: https://github.com/yourusername/ipxe-menu-generator/releases/tag/v1.0.0
