"""Entry point for running as a module: python -m ipxe_menu_gen"""

from .cli import main

if __name__ == "__main__":
    main()
